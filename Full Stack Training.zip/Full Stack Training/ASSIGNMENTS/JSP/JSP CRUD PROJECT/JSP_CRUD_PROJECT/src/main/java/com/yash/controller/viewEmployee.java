package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.dao.EmployeeDao;
import com.yash.model.Employee;

/**
 * Servlet implementation class viewEmployee
 */
@WebServlet("/viewEmployee")
public class viewEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewEmployee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='insertEmployee.jsp'>Add new Employee</a>");
		out.println("<h1>Employee List</h1>");
		
		List<Employee> list=EmployeeDao.getAllRecords();
		
		out.print("<table border='3' width='90%'>");
		out.print("<tr><th>Id</th><th>Name</th><th>Password</th><th>Email</th><th>Edit</th><th>Delete</th></tr>");
		
		for(Employee e:list) {
			out.print("<tr><td>"+e.getId()+"</td><td>"+e.getName()+"</td><td>"+e.getPassword()+"</td><td>"+e.getEmail()+"</td><td><a href='edit?id="+e.getId()+"'>edit</a></td><td><a href='delete?id="+e.getId()+"'>delete</a></td></tr>");
		}
		
		out.print("</table>");
		
		out.close();
		
		
	}

}
