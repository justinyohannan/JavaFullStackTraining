package com.yash.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.yash.model.Employee;

public class EmployeeDao {
	

	public static Connection getConnection() {
		
		String url="jdbc:mysql://localhost:3306/jspcrudproject";
		String user="root";
		String pass="root";
		Connection con=null;
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,pass);
			
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
		}
		
		return con;
	}
	
	public int insertEmployee(Employee emp) {
		
		int status=0;
		
		try {
			
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("insert into EMPLOYEE(id,name,password,email) values(?,?,?,?)");
			
			ps.setInt(1, emp.getId());
			ps.setString(2, emp.getName());
			ps.setString(3, emp.getPassword());
			ps.setString(4, emp.getEmail());
	
			status=ps.executeUpdate();
			
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
		}
		
		return status;
		
	}
	
	
	public static List<Employee> getAllRecords(){
		
		List<Employee> list=new ArrayList<Employee>();
		
		try{
			
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("select * from EMPLOYEE");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
				
				Employee emp=new Employee();
				emp.setId(rs.getInt("id"));
				emp.setName(rs.getString("name"));
				emp.setPassword(rs.getString("password"));
				emp.setEmail(rs.getString("email"));
				
				list.add(emp);
			}
			
			con.close();
			
		}
		
		catch(Exception e){
		
			e.printStackTrace();;
		
		}
		
		return list;
	}
	

	public void delete(int id) {
		// TODO Auto-generated method stub
		
		int status=0;
		
		try {
			
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("delete from EMPLOYEE where id=?");
			
			ps.setInt(1, id);
				
			status=ps.executeUpdate();
			
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
		}
		
		
		
		
	}



	public int update(Employee emp) {
		// TODO Auto-generated method stub
		
		int status=0;
		
		try {
			
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("update EMPLOYEE set name=?,password=?,email=? where id=?");
			
			
			ps.setString(1, emp.getName());
			ps.setString(2, emp.getPassword());
			ps.setString(3, emp.getEmail());
			ps.setInt(4, emp.getId());
			
			status=ps.executeUpdate();
			
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
		}
		
		return status;
	
	}

	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		
		Employee emp = null;
		
		try {
			
			Connection con= getConnection();
			PreparedStatement ps=con.prepareStatement("select * from EMPLOYEE where id = ?");
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
				
				emp = new Employee();
				emp.setId(rs.getInt("id"));
				emp.setName(rs.getString("Name"));
				emp.setPassword(rs.getString("password"));
				emp.setEmail(rs.getString("email"));
			
			}
			
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
		return emp;
	}
}
