package register;

public class patientdetails {
	public patientdetails() {
		
	}
	
	private String name;
	private String age;
	private String blood;
	private String num;
	
	public void setName(String name) {
		this.name=name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setAge(String age) {
		this.age=age;
	}
	
	public String getAge() {
		return age;
	}
	
	public void setBlood(String blood) {
		this.blood=blood;
	}
	
	public String getBlood() {
		return blood;
	}
	
	public void setNum(String num) {
		this.num=num;
	}
	
	public String getNum() {
		return num;
	}
	
	
	
	
}
