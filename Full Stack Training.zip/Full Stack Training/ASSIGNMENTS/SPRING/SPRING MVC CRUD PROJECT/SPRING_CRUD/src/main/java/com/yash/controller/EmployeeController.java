package com.yash.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import com.yash.dao.EmployeeDao;
import com.yash.entities.Employee;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeDao empdao;

	@RequestMapping("/")
	public String home(Model m) {
		
		List<Employee> employee = empdao.getAllEmployee();
		m.addAttribute("emp", employee);
		
		return "index";
	}
	
	@RequestMapping("/add")
	public String addEmployee(Model m) {
		
		m.addAttribute("title", "Add Employee");
		return "addemployee";
	}
	
	//to add employee
	@RequestMapping(value = "/handleEmp", method = RequestMethod.POST)
	public RedirectView handleEmployee(@ModelAttribute Employee emp,HttpServletRequest request) {
		
		System.out.println(emp);
		empdao.addEmployee(emp);
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath()+"/");
		return redirectView;
	}
	
	
	//to delete employee
	@RequestMapping("/delete/{empId}")
	public RedirectView deleteEmployee(@PathVariable("empId") int eId, HttpServletRequest request) {
		
		this.empdao.deleteEmployee(eId);
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath()+"/");
		return redirectView;
		
	}
	
	
	//to update employee details
	@RequestMapping("/update/{empId}")
	public String updateForm(@PathVariable("empId") int eid,Model model) {
		
		Employee emp = this.empdao.getEmployee(eid);
		model.addAttribute("emp", emp);
		return "updateemployee";
	}
	
	
	
}
