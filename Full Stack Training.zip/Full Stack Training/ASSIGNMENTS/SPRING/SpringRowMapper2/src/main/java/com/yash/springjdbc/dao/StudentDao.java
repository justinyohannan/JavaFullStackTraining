package com.yash.springjdbc.dao;

import java.util.List;

import com.yash.springjdbc.entities.Student;

public interface StudentDao {

	public int insert(Student stu);//
	public int updatedetails(Student stu);
	public int deletedetails(int stuid);
	
	//public Student selectDetails(int stuid);//row mapper for single object
	
	public List<Student> getAllStudents(); //to fetch all data from Student table by using row mapper

}