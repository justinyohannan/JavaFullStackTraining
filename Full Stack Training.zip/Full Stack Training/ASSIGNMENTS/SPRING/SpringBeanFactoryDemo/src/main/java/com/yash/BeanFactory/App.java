package com.yash.BeanFactory;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class App {

	public static void main(String[] args) {
		
		System.out.println("Spring program using BeanFactory");
		Resource resource = new ClassPathResource("com/yash/BeanFactory/applicationcontext.xml");
		BeanFactory factory = new XmlBeanFactory(resource);
		//here xmlbeanfactory is deprecated thats why we are using applicationcontext 
		//so it is not recommended to use beanfactory
		//we can use applicationcontext
		Employee e=(Employee)factory.getBean("emp");
		System.out.println(e);
		
	}
}
