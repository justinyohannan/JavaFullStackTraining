package com.yash.SpringJDBC;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/SpringJDBC/applicationcontext.xml");
				JdbcTemplate temp=context.getBean("jdbctemp2",JdbcTemplate.class);
				String emp="insert into employee(id,name,email) values(?,?,?)";
		
			int msg1=temp.update(emp,4,"Justin Yohannan","justin.yohannan@yash.com");
			int msg2=temp.update(emp,5,"Ravi Sharma","ravi.sharma@yash.com");
			
			System.out.println("Successfully inserted records");
		
	}
	
}
