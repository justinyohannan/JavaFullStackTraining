package com.yash.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springjdbc.dao.EmployeeDao;
import com.yash.springjdbc.entities.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
    	System.out.println("Employee Details");
    	ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
    	EmployeeDao empdao=context.getBean("EmployeeDao",EmployeeDao.class);
    	
    	Employee e=new Employee();
    	e.setEmpid(11);
    	e.setEmpname("JAY SHARMA");
    	e.setEmailid("jay.sharma@yash.com");
    	e.setDob("1996/03/24");
    	e.setContactno("9798775678");
    	e.setSalary(11000);
    	
//    	e.setEmpid(13);
//    	e.setEmpname("Ram");
//    	e.setEmailid("ram@yash.com");
//    	e.setDob("1996/12/20");
//    	e.setContactno("8997333409");
//    	e.setSalary(10000);
    	
//    	int r = empdao.insert(e);
//    	System.out.println(r + " Employee added successfully");
    	
    	int r = empdao.updatedetails(e);
    	System.out.println(r + " Employee details updated");
    	
//    	int r = empdao.deletedetails(11);
//    	System.out.println(r + " Employee deleted successfully");
    	
    	
    	
    }
}
