package com.yash.springjdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.entities.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbctemp;

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public int insert(Employee emp) {
		
		// to insert employee details
		String q="insert into employee(empid,empname,emailid,dob,contactno,salary) values(?,?,?,?,?,?)";
		int msg=this.jdbctemp.update(q,emp.getEmpid(),emp.getEmpname(),emp.getEmailid(),emp.getDob(),emp.getContactno(),emp.getSalary());
		return msg;
	}

	public int updatedetails(Employee emp) {
		
		// to update employee details
		String q="update employee set empname=? , emailid=? , dob=? , contactno=? , salary=? where empid=?";
		int msg=this.jdbctemp.update(q,emp.getEmpname(),emp.getEmailid(),emp.getDob(),emp.getContactno(),emp.getSalary(),emp.getEmpid());
		return msg;
	}

	public int deletedetails(int empid) {
		
		// to delete employee details
		String q="delete from employee where empid=?";
		int msg=this.jdbctemp.update(q,empid);
		return msg;
	}
	
	
}
