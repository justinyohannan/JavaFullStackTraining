package com.yash.springjdbc.entities;

public class Employee {

	private int empid;
	private String empname;
	private String emailid;
	private String dob;
	private String contactno;
	private double salary;
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public Employee(int empid, String empname, String emailid, String dob, String contactno, double salary) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.emailid = emailid;
		this.dob = dob;
		this.contactno = contactno;
		this.salary = salary;
	}
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", emailid=" + emailid + ", dob=" + dob
				+ ", contactno=" + contactno + ", salary=" + salary + "]";
	}
	
	
	
}