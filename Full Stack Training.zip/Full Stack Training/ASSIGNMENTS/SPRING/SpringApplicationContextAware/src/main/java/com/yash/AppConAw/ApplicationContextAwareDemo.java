package com.yash.AppConAw;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class ApplicationContextAwareDemo implements ApplicationContextAware {

	private ApplicationContext appcon;
	
	@Override
	public void setApplicationContext(ApplicationContext appcon) throws BeansException{
		System.out.println("create another bean");
		this.appcon = appcon;
	}
	
	public void createBean() {
		Employee e=appcon.getBean("emp",Employee.class);
		System.out.println(e);
	}
	
	
}
