package com.yash.AppConAware;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/AppConAware/applicationcontext.xml");
		AppContAwareDemo appconaware = context.getBean("appconaw",AppContAwareDemo.class);
		
		appconaware.displayEmployeeDetails();
		
	}
	
}
