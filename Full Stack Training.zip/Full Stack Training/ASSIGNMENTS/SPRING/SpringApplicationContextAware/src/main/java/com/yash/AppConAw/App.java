package com.yash.AppConAw;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/AppConAw/applicationcontext.xml");
		ApplicationContextAwareDemo appconaware = context.getBean("appconaw",ApplicationContextAwareDemo.class);
		appconaware.createBean();
		
	}
	
}
