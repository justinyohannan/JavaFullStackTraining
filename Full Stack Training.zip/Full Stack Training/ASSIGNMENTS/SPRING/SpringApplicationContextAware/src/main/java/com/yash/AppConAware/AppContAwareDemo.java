package com.yash.AppConAware;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class AppContAwareDemo implements ApplicationContextAware {

	private ApplicationContext appcon;

	@Override
	public void setApplicationContext(ApplicationContext appcon) throws BeansException {
		
		System.out.println("In the applicationcontext method");
		this.appcon=appcon;
	}
	
	public void displayEmployeeDetails() {
		
		Employee e=appcon.getBean("emp",Employee.class);
		System.out.println(e);
		
	}
	
	
	
}
 