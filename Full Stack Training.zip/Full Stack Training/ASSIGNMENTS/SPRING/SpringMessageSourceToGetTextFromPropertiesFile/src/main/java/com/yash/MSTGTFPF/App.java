package com.yash.MSTGTFPF;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/MSTGTFPF/applicationcontext.xml");
		
		System.out.println(context.getMessage("message", null, "Default Message", null));
		
		Employee e1 = context.getBean("emp1",Employee.class);
		System.out.println(e1);
		
		Employee e2 = context.getBean("emp2",Employee.class);
		System.out.println(e2);
		
		Employee e3 = context.getBean("emp3",Employee.class);
		System.out.println(e3);
		
		Employee e4 = context.getBean("emp4",Employee.class);
		System.out.println(e4);
		
		
		
		((AbstractApplicationContext) context).close();
		
	}
}
