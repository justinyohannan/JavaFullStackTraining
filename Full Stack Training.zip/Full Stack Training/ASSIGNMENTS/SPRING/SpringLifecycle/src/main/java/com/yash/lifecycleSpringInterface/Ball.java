package com.yash.lifecycleSpringInterface;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

//InitializingBean is the interface used for bean initialization
//DisposableBean is the interface used for destroying bean
public class Ball implements InitializingBean,DisposableBean {

	private String shape;

	public String getShape() {
		return shape;
	}

	public void setShape(String shape) {
		this.shape = shape;
	}

	public Ball() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Ball [shape=" + shape + "]";
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		
		//method of InitializingBean
		//this method works like init
		System.out.println("calling init method");
		
	}

	@Override
	public void destroy() throws Exception {
		
		//method of DisposableBean
		//this method works for destroying bean
		System.out.println("calling destroy method");
		
	}
	
	
	
}
