package com.yash.lifecycleXML;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("com/yash/lifecycleXML/applicationcontext.xml");
		Employee e=(Employee)context.getBean("emp");
		
		System.out.println(e.getId());
		System.out.println(e.getName());
		
		//method for destroy()
		//here we are registering shutdown hook
		context.registerShutdownHook();
		
	}
	
}
