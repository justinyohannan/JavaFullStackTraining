package com.yash.lifecycleAnnotation;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Apple {

	private String taste;

	public String getTaste() {
		return taste;
	}

	public void setTaste(String taste) {
		this.taste = taste;
	}

	public Apple() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Apple [taste=" + taste + "]";
	}
	
	@PostConstruct
	public void create() {
		System.out.println("starting");
	}
	
	@PreDestroy
	public void delete() {
		System.out.println("ending");
	}
}
