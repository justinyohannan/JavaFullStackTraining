package com.yash.lifecycleAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("com/yash/lifecycleAnnotation/applicationcontext.xml");
		Apple a=(Apple)context.getBean("apple");
		
		System.out.println(a);
		
		//method for destroy()
		//here we are registering shutdown hook
		context.registerShutdownHook();
		
	}
	
}
