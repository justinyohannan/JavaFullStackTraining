package com.yash.lifecycleSpringInterface;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("com/yash/lifecycleSpringInterface/applicationcontext.xml");
		Ball ball=(Ball)context.getBean("b");
		
		System.out.println(ball);
		
		//method for destroy()
		//here we are registering shutdown hook
		context.registerShutdownHook();
		
	}
	
}
