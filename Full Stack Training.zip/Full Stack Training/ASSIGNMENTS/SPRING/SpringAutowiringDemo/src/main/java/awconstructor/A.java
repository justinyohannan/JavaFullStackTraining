package awconstructor;

public class A {

}
