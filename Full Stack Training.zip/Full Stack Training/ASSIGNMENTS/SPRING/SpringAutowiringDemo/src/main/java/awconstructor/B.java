package awconstructor;

public class B {

}
