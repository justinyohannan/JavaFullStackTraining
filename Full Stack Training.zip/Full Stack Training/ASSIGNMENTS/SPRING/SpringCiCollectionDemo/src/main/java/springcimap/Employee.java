package springcimap;

import java.util.Map;

public class Employee {

	private String name;
	private Map address;
	
	public Employee(String name, Map address) {
		super();
		this.name = name;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map getAddress() {
		return address;
	}

	public void setAddress(Map address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return this.name+" : "+this.address;
	}
	
	
	
	
}
