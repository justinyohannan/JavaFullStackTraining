package springciproperties;

import java.util.Properties;

public class Employee {

	private String name;
	private Properties location;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Properties getLocation() {
		return location;
	}
	public void setLocation(Properties location) {
		this.location = location;
	}
	
	
	
	public Employee(String name, Properties location) {
		super();
		this.name = name;
		this.location = location;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + "]";
	}

	
	
}
