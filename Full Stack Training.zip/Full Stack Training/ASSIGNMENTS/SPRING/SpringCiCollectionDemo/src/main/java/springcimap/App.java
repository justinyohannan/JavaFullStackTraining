package springcimap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		System.out.println("spring program for map with ci");
		ApplicationContext context=new ClassPathXmlApplicationContext("springcimap/applicationcontext.xml");
		Employee e=(Employee)context.getBean("emp1");
		System.out.println(e);
		
	}
	
}
