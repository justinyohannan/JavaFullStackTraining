package springciset;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		System.out.println("spring program for set using ci");
		ApplicationContext context = new ClassPathXmlApplicationContext("springciset/applicationcontext.xml");
		Employee e=(Employee)context.getBean("emp1");
		System.out.println(e);
		
	} 
	
}
