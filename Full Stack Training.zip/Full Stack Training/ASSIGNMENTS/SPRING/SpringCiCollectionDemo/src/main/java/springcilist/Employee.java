package springcilist;

import java.util.List;

public class Employee {

	private String name;
	private List<String> pnum;
	
	public Employee(String name, List<String> pnum) {
		
		this.name = name;
		this.pnum = pnum;
	}


	@Override
	public String toString() {
		return this.name+" : "+this.pnum;
	}
	
	
	
}
