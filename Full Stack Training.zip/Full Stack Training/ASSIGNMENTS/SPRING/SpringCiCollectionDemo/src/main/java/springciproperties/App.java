package springciproperties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		System.out.println("spring program for properties using ci");
		ApplicationContext context = new ClassPathXmlApplicationContext("springciproperties/applicationcontext.xml");
		Employee e=(Employee)context.getBean("emp1");
		System.out.println(e.getLocation());
		
	} 
	
}
