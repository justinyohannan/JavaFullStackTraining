package springciset;

import java.util.Set;

import org.springframework.core.style.ToStringCreator;

public class Employee {

	private String name;
	private Set<String> address;
	
	public Employee(String name, Set<String> address) {
	
		this.name = name;
		this.address = address;
	}

	
	
	
	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public Set<String> getAddress() {
		return address;
	}




	public void setAddress(Set<String> address) {
		this.address = address;
	}




	@Override
	public String toString() {
		
		return this.name+" : "+this.address;
	}
		
	
	
	
	
}
