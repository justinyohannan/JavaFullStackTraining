package com.yash.SpringJDBCDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class App 
{
    public static void main( String[] args ) {
    	
    	ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/SpringJDBCDemo/applicationcontext.xml");
    			JdbcTemplate temp=context.getBean("jdbctemp",JdbcTemplate.class);
    			String q = "insert into student(id,name) values(?,?)";
    			
    			int msg= temp.update(q,100,"Shyam");
    			System.out.println("record inserted " + msg);
    			
    			
    			
    }
}
