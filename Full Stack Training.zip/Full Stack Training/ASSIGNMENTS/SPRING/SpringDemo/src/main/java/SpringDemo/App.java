package SpringDemo;

import SpringDemo.Employee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class App {

	public static void main(String[] args) {
		
		//here we have done program of ioc with the help of ApplicationContext
		System.out.println("Welcome to spring application");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		Employee e=(Employee)context.getBean("employee");
		System.out.println(e);
		
		Employee e1=(Employee)context.getBean("employee1");
		System.out.println(e1);
		
		
	}
}
