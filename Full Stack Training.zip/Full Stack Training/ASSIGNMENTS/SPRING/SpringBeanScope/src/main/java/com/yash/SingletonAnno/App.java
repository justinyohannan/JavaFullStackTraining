package com.yash.SingletonAnno;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/SingletonAnno/applicationcontext.xml");
		Pen p1=context.getBean("pen",Pen.class);
		System.out.println(p1.hashCode());
		
		Pen p2=context.getBean("pen",Pen.class);
		System.out.println(p2.hashCode());
	}
}
