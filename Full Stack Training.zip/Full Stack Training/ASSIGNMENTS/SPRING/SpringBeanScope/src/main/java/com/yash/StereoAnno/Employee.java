package com.yash.StereoAnno;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//if we live blank after @Component then we get bean name=employee
//if we write @Component("emp") then we get bean name=emp 
@Component("emp")
public class Employee {
	//here by using this we set properties value=Justin
	@Value("Justin")
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + "]";
	}
	
	
}
