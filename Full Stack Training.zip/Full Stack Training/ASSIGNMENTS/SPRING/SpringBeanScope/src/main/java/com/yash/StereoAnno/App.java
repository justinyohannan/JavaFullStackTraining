package com.yash.StereoAnno;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/StereoAnno/applicationcontext.xml");
		//Here we use @Component is used we get bean name = class name(in small letter)
		//here by using @Component we don't need to make bean part in applicationcontext.xml file
		//Employee e=(Employee)context.getBean("employee");
		//System.out.println(e);
		
		Employee e=(Employee)context.getBean("emp");
		System.out.println(e);
		
	}
	
}
