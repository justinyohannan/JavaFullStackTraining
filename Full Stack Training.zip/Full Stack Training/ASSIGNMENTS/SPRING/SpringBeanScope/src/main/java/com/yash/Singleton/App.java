package com.yash.Singleton;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/Singleton/applicationcontext.xml");
		Employee e1=(Employee)context.getBean("emp");
		System.out.println(e1.hashCode());
		
		Employee e2=(Employee)context.getBean("emp");
		System.out.println(e2.hashCode());
		
	}
	
}
