package com.yash.springorm.dao;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.yash.springorm.entities.Student;

public class StudentDao {
	private HibernateTemplate hibernatetemp;

	@Transactional
	public int insert(Student stu) {
		Integer i = (Integer) this.hibernatetemp.save(stu);
		return i;
	}
	
	public  getStudentDetails(Student s) {
		
		Student stu=this.hibernatetemp.get(Student.class,s);
		return stu;
	}
	//we only use Transactional annotation while inserting, deleting and updating the data
	//we cannot use Transactional annotation while fetching the data from database
	public List<Student> getAllStudents(int stuid) {
		
		List<Student> stu=this.hibernatetemp.loadAll(Student.class);
		return stu;
	}
	
	@Transactional
	public int deleteDetails(int stuid) {
		
		Student stu=this.hibernatetemp.get(Student.class,stuid);
		this.hibernatetemp.delete(stu);
		
		return stuid;
	}

	@Transactional
	public int updateDetails(Student stu) {
		
		this.hibernatetemp.update(stu);
		return 1;

	}
	
	public HibernateTemplate getHibernatetemp() {
		return hibernatetemp;
	}

	public void setHibernatetemp(HibernateTemplate hibernatetemp) {
		this.hibernatetemp = hibernatetemp;
	}

	
}	