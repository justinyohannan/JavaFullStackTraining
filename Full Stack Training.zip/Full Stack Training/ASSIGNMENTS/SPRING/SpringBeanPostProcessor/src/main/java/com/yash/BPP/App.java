package com.yash.BPP;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("com/yash/BPP/applicationcontext.xml");
		Rectangle r = context.getBean("rect",Rectangle.class);
		
		System.out.println(r);
		
		context.registerShutdownHook();
		
	}
	
}
