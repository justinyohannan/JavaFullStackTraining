package com.yash.BPP;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class InitRectangle implements BeanPostProcessor {

	public java.lang.Object postProcessBeforeInitialization(java.lang.Object bean, String beanName)
			throws BeansException {
		
		System.out.println("length=? breadth=?");
		return bean;
	}

	public java.lang.Object postProcessAfterInitialization(java.lang.Object bean, String beanName)
			throws BeansException {
		
		System.out.println("got the results");
		return bean;
	}

}
