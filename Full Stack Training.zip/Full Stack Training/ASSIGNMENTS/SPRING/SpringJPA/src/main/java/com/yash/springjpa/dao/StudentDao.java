package com.yash.springjpa.dao;

public class StudentDao {

	private JpaTemplate jpatemp;
	
}
