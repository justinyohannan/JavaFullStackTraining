package springciref;

public class A {

	private int x;
	private B b;
	
	public A(int x) {
		this.x=x;
	}
	
	public A(B b) {
		this.b=b;
	}
	
	public A(int x,B b) {
		this.x=x;
		this.b=b;
	}

	@Override
	public String toString() {
		return "A [x=" + x + ", b=" + b + "]";
	}
	
	
	
}
