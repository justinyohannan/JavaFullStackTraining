package springciref;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		System.out.println("Spring program for constructor injection using reference");
		ApplicationContext context=new ClassPathXmlApplicationContext("springciref/applicationcontext.xml");
		
		A a=(A)context.getBean("refa");
		System.out.println(a);
		
//		B b=(B)context.getBean("refb");
//		System.out.println(b);
		
		
		
	}
	
}
