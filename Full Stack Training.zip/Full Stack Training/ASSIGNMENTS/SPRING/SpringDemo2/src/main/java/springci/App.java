package springci;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		System.out.println("Spring program using constructor injection(ci)");
		ApplicationContext context=new ClassPathXmlApplicationContext("springci/applicationcontext.xml");
		//reference work is done in applicationcontext.xml file
		Employee e=(Employee)context.getBean("empci");
		System.out.println(e);
		
		Employee e1=(Employee)context.getBean("empci1");
		System.out.println(e1);
		
	}
	
}
