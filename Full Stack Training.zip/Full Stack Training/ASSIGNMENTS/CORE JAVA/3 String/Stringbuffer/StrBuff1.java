class StrBuff1
{
	public static void main(String[] args)
	{
		StringBuffer sb1 = new StringBuffer("Yash");
		StringBuffer sb2 = new StringBuffer("Justin");
		System.out.println(sb1.equals(sb2));
	}
}