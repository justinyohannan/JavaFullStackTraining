class StrBuff2
{
	public static void main(String[] main)
	{
		StringBuffer sb = new StringBuffer();
		sb.ensureCapacity(63);
		System.out.println(sb.capacity());
		sb.append("Justin Yohannan");
		sb.trimToSize();
		System.out.println(sb.capacity());
	}
}