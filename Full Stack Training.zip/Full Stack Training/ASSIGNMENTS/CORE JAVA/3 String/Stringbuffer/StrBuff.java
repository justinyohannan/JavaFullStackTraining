class StrBuff
{
	public static void main(String[] args)
	{
	
		StringBuffer sb=new StringBuffer("Hello, how are you?");
		//System.out.println(sb1.capacity());
		//System.out.println(sb.charAt(3));
		//System.out.println(sb.delete(0,5));
		//System.out.println(sb.deleteCharAt(4));
		//System.out.println(sb.insert(0,"Hi "));
		//System.out.println(sb.indexOf("o"));
		//System.out.println(sb.lastIndexOf("h"));
		//System.out.println(sb.reverse());
		//System.out.println(sb.replace(3,7,"Bye"));
		//System.out.println(sb.subSequence(5,12));
		//System.out.println(sb.substring(3,10));
		sb.setCharAt(8,'t');
		System.out.println(sb);
	}
}