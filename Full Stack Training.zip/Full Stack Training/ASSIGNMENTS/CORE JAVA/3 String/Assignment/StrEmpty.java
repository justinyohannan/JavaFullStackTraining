class StrEmpty
{
	public static void main(String[] args)
	{
		String s ="Justin";
		System.out.println(s.isEmpty());
	}
}