class StrPal
{
	public static void main(String[] args)
	{
		String s = args[0];
		String s1 = "";
		int length=s.length();
		for(int i=length-1;i>=0;i--)
		{
			s1=s1+s.charAt(i);
		}
		if (s.equals(s1))  
		{
			System.out.println("Entered string is a palindrome");  
		}
		else  
		{	
			System.out.println("Entered string isn't a palindrome");  
		}
	}
}