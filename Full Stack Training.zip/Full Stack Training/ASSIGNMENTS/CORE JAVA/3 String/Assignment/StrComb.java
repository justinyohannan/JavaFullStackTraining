class StrComb{
	public static void main(String[] args){
		
		String s1 = args[0];
		String s2 = args[1];
		
		int i = 0;
		int j = 0;
		
		while(i < s1.length() && j < s2.length()){
			System.out.print(s1.charAt(i));
			i++;
			System.out.print(s2.charAt(j));
			j++;
		}
		
		while(i < s1.length()){
			System.out.print(s1.charAt(i));
			i++;
		}
		
		while(j < s2.length()){
			System.out.print(s2.charAt(j));
			j++;
		}
	}
}