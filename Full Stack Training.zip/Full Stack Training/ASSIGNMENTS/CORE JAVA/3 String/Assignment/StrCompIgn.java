class StrCompIgn
{
	public static void main(String[] args)
	{
		String s1 ="JUSTIN YOHANNAN";
		String s2 ="justin yohannan";
		System.out.println(s1.compareToIgnoreCase(s2));
	}
}