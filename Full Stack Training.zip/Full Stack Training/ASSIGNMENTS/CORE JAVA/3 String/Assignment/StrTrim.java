class StrTrim
{
	public static void main(String[] args)
	{
		String s ="    Justin Yohannan    ";
		System.out.println(s.trim());
		System.out.println(s);
	}
}