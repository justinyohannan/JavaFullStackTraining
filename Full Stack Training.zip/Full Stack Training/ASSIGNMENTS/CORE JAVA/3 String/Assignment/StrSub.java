class StrSub
{
	public static void main(String[] args)
	{
		String s ="justin yohannan";
		System.out.println(s.substring(8,11));
	}
}