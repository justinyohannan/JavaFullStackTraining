class StrComp
{
	public static void main(String[] args)
	{
		String s1 ="yash";
		String s2 ="yas";
		System.out.println(s1.compareTo(s2));
	}
}