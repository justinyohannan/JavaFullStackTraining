import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.ArrayList;

class RegexAssign2{
	public static void main(String[] args){
		ArrayList<String> outputLineByLine = new ArrayList<>();
		
		String str = "Something \n sensible  \n is being written";
		
		Pattern p = Pattern.compile("(.+\\n|.+)");
		Matcher m = p.matcher(str);
		while(m.find()){
			outputLineByLine.add(m.group());
		}
		
		System.out.println(outputLineByLine);
		
	}
}