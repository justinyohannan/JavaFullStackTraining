//Regex Assignment 1
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Scanner;

class RegexAssign1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String:");
		String s=sc.nextLine();
		String s1="\\d";
		Pattern p=Pattern.compile(s1);
		Matcher m=p.matcher(s);
		System.out.println("the numbers are:");
		while(m.find())
		{
			System.out.println(m.group()+" ");
		}
	}
}