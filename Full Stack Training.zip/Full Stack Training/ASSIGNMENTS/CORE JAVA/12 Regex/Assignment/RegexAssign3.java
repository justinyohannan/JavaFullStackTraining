import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.ArrayList;

class RegexAssign3{
	public static void main(String[] args)
	{
		// Brute force way
		ArrayList<Integer> primeNo = new ArrayList<>();
		String str = "676 321 55 67 454 13 7";
		Pattern p = Pattern.compile("\\d+(?=\\s|)");
		Matcher m = p.matcher(str);
		while(m.find()){
			int i = Integer.parseInt(m.group());
			if(prime(i)){
				primeNo.add(i);
			}
		}
		
		System.out.println(primeNo);
	}
	
	static Boolean prime(int n){
		for(int i = 2; i < n/2; i++){
			if(n % i == 0){
				return false;
			}
		}
		return true;
	}
}