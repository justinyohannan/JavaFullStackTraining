// Regex Assignment4
import java.util.regex.Pattern;
import java.util.regex.Matcher;

class RegexAssign4
{
	public static void main(String[] args)
	{
		String s="Welcome to 'Yash Technology'";
		Pattern p=Pattern.compile("'(.*?)'");
		Matcher m=p.matcher(s);
		if(m.find())
		{
			System.out.println(m.group());
		}
		
	}	
}