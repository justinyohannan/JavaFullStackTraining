class Health
{
	String patientName;
	double height;
	double weight;
	public Health(String patientName,double weight,double height)
	{
		this.patientName=patientName;
		this.height=height;
		this.weight=weight;
		
	}
	public double bmi()
	{
		return (weight/height*height);
	} 
}
class Patient
{
	public static void main(String[] args)
	{
		Health p=new Health("Justin",70.3,1.56);
		System.out.println(p.bmi());
	}
}