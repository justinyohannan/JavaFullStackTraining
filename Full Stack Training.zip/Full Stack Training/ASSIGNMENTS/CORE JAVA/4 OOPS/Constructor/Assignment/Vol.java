class CubeBox
{
	double width;
	double height;
	double depth;
	CubeBox(double width,double height,double depth)
	{
		this.width=width;
		this.height=height;
		this.depth=depth;
	}
	double calVolume()
	{
		return (width*height*depth);
	}
}
class Vol
{
	public static void main(String[] args)	
	{
		CubeBox c=new CubeBox(2.3,4.2,5);
		System.out.println(c.calVolume());
	}
}