//Interface Assignment
interface LibraryUser
{
	public abstract void registerAccount();
	public abstract void requestBook();
}
class KidUsers implements LibraryUser
{
	private int age;
	private String bookType;
	public void setAge(int age)
	{
		this.age=age;
	}
	public void setBookType(String bookType)
	{
		this.bookType=bookType;
	}
	public void registerAccount()
	{
		if(age<12)
		{
			System.out.println("You have succcessfully registered under a kids account");
		}
		if(age>12)
		{
			System.out.println("Sorry age must be less than 12 to register as a kid");
		}
		
	}
	public void requestBook()
	{
		if(bookType.equals("Kids"))
		{
			System.out.println("Book issued successfully, please return the book within 10 days");
		}
		else
		{
			System.out.println("Oops, you are allowed to take only kids books");
		}
	}
}
class AdultUsers implements LibraryUser
{
	private int age;
	private String bookType;

	public void setAge(int age)
	{
		this.age=age;
	}
	public void setBookType(String bookType)
	{
		this.bookType=bookType;
	}
	public void registerAccount()
	{
		if(age>12)
		{
			System.out.println("You have succcessfully registered under an adult account");
		}
		if(age<12)
		{
			System.out.println("Sorry age must be greater than 12 to register as a adult");
		}
		
	}
	public void requestBook()
	{
		if(bookType.equals("Fiction"))
		{
			System.out.println("Book issued successfully, please return the book within 7 days");
		}
		else
		{
			System.out.println("Oops, you are allowed to take only adult fiction books");
		}
	}
}
class LibraryInterfaceDemo
{
	public static void main(String[] args)
	{
		KidUsers k=new KidUsers();
		k.setAge(11);
		k.setBookType("Kids");
		k.registerAccount();
		k.requestBook();
		
		AdultUsers ad=new AdultUsers();
		ad.setAge(13);
		ad.setBookType("Fiction");
		ad.registerAccount();
		ad.requestBook();
	}
}