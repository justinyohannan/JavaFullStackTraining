//super keyword can be used to invoke immediate parent class method
class A
{
	void show()
	{
		System.out.println("Method A");
	}
}
class Super2 extends A
{
	void display()
	{
		System.out.println("Method Super2");
	}
	void show()
	{
		display();
		super.display();
	}
	public static void main(String[]args)
	{
		Super2 s=new Super2();
		s.show();
	}
}