//Super keyword can be used to refer immediate parent class instance variable
class A
{
	int a=100;
}
class Super1 extends A
{
	int a=200;
	void display(int a)
	{
		System.out.println();
	}
	public static void main(String[]args)
	{
		Super1 s=new Super1();
		s.show(300);
	}
}