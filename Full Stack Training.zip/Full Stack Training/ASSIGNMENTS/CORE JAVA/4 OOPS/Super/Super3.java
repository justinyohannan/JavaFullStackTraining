//
class A
{
	A()
	{
		System.out.println("class A");
	}
}
class Super3 extends A
{
	Super3()
	{
		super();
		System.out.println("class Super3");
	}
	public static void main(String[]args)
	{
		Super3 s=new Super3();
		
	}
}