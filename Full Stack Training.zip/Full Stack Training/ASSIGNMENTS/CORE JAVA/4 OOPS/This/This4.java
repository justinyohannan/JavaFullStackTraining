//this can be used to pass an argument in the method call
class This4
{
	void y1(This4 t)
	{
		System.out.println("y1");
	}
	void y2()
	{
		y1(this);
	}
	public static void main(String[] args)
	{
		This4 t=new This4();
		t.y2();
	}
}