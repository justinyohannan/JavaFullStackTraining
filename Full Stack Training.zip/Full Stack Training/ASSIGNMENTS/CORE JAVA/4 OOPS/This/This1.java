//this keyword is used to refer current class instance variable
class Demo
{
	int i;
	void setValue(int i)
	{
		this.i=i;
	}
	void show()
	{
		System.out.println(i);
	}
}
class This1
{
	public static void main(String[] args)
	{
		Demo d=new Demo();
		d.setValue(15);
		d.show();
	}
}


