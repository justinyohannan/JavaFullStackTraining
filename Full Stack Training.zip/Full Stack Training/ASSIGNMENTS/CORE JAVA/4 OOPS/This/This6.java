//this can be used to return the current class instance from the method
//Java code for using 'this' keyword
//to return the current class instance
class This6
{
	int a;
	int b;
	This6()
	{
		a = 10;
		b = 20;
	}
	This6 get()
	{
		return this;
	}
	
	void display()
	{
		System.out.println("a = " + a + " b = " + b);
	}

	public static void main(String[] args)
	{
		This6 t = new This6();
		t.get();
		t.display();
	}
}
