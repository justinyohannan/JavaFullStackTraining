//this keyword used to invoke current class constructor
class This3
{
	This3()
	{
		System.out.println("no argument");
	}
	This3(int a)
	{
		this();
		System.out.println("Parameterized");
	}
	public static void main(String[] args)
	{
		This3 t=new This3();
	}
}