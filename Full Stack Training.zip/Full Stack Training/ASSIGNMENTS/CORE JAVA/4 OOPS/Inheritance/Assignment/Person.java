class Person
{
	String name;
	int dateOfBirth;
	Person()
	{
		this.name=name;
		this.dateOfBirth=dateOfBirth;
	}
	public void setName(String name)
	{
			this.name=name;
	}
	public void setDateOfBirth(int dateOfBirth)
	{
		this.dateOfBirth=dateOfBirth;
	}
	public String getName()
	{
		return name;
	}
	public int getDateOfBirth()
	{
		return dateOfBirth;
	}
}
class Teacher extends Person
{
	double salary;
	String subject;
	Teacher()
	{
		this.salary=salary;
		this.subject=subject;
	}
	public void setSalary(double salary)
	{
		this.salary=salary;
	}
	public void setSubject(String subject)
	{
		this.subject=subject;
	}
	public double getSalary()
	{
		return salary;
	}
	public String getSubject()
	{
		return subject;
	}
}
class Student extends Person
{
	int studentId;
	Student()
	{
		this.studentId=studentId;
	}
	public void setStudentId(int studentId)
	{
		this.studentId=studentId;
	}
	public int getStudentId()
	{
		return studentId;
	}
}
class CollegeStudent extends Student
{
	String collegeName;
	String year;
	CollegeStudent()
	{
		this.collegeName=collegeName;
		this.year=year;
	}
	public void setCollegeName(String collegeName)
	{
		this.collegeName=collegeName;
	}
	public void setYear(String year)
	{
		this.year=year;
	}
	public String getCollegeName()
	{
		return collegeName;
	}
	public String getYear()
	{
		return year;
	}
	public static void main(String[] args)
	{
		Person p=new Person();
		p.setName("Justin");
		System.out.println(p.getName());
		p.setDateOfBirth(24031998);
		System.out.println(p.getDateOfBirth());
		Teacher t=new Teacher();
		t.setName("Rajesh");
		System.out.println(t.getName());
		t.setDateOfBirth(5121986);
		System.out.println(t.getDateOfBirth());
		t.setSalary(55421);
		System.out.println(t.getSalary());
		t.setSubject("Maths");
		System.out.println(t.getSubject());
		Student s=new Student();
		s.setName("JustinYohannan");
		System.out.println(s.getName());
		s.setDateOfBirth(24031998);
		System.out.println(s.getDateOfBirth());
		s.setStudentId(4565);
		System.out.println(s.getStudentId());
		CollegeStudent cs=new CollegeStudent();
		cs.setName("Justin Yohannan");
		System.out.println(cs.getName());
		cs.setDateOfBirth(24031998);
		System.out.println(cs.getDateOfBirth());
		cs.setStudentId(4565);
		System.out.println(cs.getStudentId());
		cs.setCollegeName("IIST");
		System.out.println(cs.getCollegeName());
		cs.setYear("fourth");
		System.out.println(cs.getYear());
	}
}