//Abstraction Assignment 1
abstract class GeneralBank
{
	abstract double getSavingsInterestRate();
	abstract double getFixedDepositInterstRate();
}
class ICICIBank extends GeneralBank
{
	double getSavingsInterestRate()
	{
		return 4;
	}
	double getFixedDepositInterstRate()
	{
		return 8.5;
	}
}
class SBIBank extends GeneralBank
{
	double getSavingsInterestRate()
	{
		return 4;
	}
	double getFixedDepositInterstRate()
	{
		return 7;
	}
}
class InterestDemo
{
	public static void main(String[] args)
	{
		ICICIBank i=new ICICIBank();
		System.out.println(i.getSavingsInterestRate());
		System.out.println(i.getFixedDepositInterstRate());
		
		SBIBank s=new SBIBank();
		System.out.println(s.getSavingsInterestRate());
		System.out.println(s.getFixedDepositInterstRate());
		
		GeneralBank g=new SBIBank();
		System.out.println(g.getSavingsInterestRate());
		System.out.println(g.getFixedDepositInterstRate());
		
		GeneralBank g2=new ICICIBank();
		System.out.println(g2.getSavingsInterestRate());
		System.out.println(g2.getFixedDepositInterstRate());
		
	}
}