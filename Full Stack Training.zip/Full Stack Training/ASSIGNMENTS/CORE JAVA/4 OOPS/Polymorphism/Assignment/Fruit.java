class Fruit
{
	String name;
	String taste;
	int size;
	void eat()
	{
		System.out.println("Fruit name:"+name);
		System.out.println("Taste of the fruit:"+taste);
	}
}
class Apple extends Fruit
{
	String name="Apple";
	String taste="Sweet";
	
	void eat()
	{
		System.out.println("Fruit name:"+name);
		System.out.println("Taste of the fruit:"+taste);
	}
}
class Orange extends Fruit
{
	String name="Orange";
	String taste="Sour";
	
	void eat()
	{
		System.out.println("Fruit name:"+name);
		System.out.println("Taste of the fruit:"+taste);
	}
	public static void main(String[] args)
	{
		Fruit f=new Fruit();
		Apple a=new Apple();
		a.eat();
		Orange o=new Orange();
		o.eat();
	}
}