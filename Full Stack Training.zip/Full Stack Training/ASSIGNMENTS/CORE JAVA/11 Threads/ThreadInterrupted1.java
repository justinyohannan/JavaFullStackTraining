
public class ThreadInterrupted1 extends Thread{
	public void run() {
		
		//System.out.println(Thread.interrupted());
		for(int i=1;i<=3;i++) {
			try {
				System.out.println(i);
				Thread.sleep(1000);
				//System.out.println(Thread.interrupted());  //here this statement can be used to check the status of thread. Here we used interrupted() method so it clears interrupted status by calling thread interrupted i.e. System.out.println(Thread.interrupted()) 
				//System.out.println(Thread.currentThread().isInterrupted());
			
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
	}
	public static void main(String[] args) {
		ThreadInterrupted1 tid=new ThreadInterrupted1();
		tid.start();
		tid.interrupt();
		
	}
}
