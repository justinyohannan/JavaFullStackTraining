//this is best program that sir created for explaining interrupted() and isInterrupted()
public class ThreadInterrupted2 extends Thread{
	public void run() {
		
		//System.out.println(Thread.interrupted());//current status-->true then it clears the status i.e. false
		//System.out.println(Thread.interrupted());//current status-->false because interrupt() method is only called once
		//System.out.println(Thread.interrupted());//current status-->false
		
		//System.out.println(Thread.currentThread().isInterrupted());//current status-->true
		//System.out.println(Thread.currentThread().isInterrupted());//current status-->true
		//System.out.println(Thread.currentThread().isInterrupted());//current status-->true
		
		for(int i=1;i<=3;i++) {
			//System.out.println(Thread.interrupted());
			//System.out.println(Thread.currentThread().isInterrupted());
			try {
				
				//System.out.println(Thread.interrupted());
				//System.out.println(Thread.currentThread().isInterrupted());
				
				System.out.println(i);
				
				//System.out.println(Thread.interrupted());
				//System.out.println(Thread.currentThread().isInterrupted());
				
				Thread.sleep(1000);
				//System.out.println(Thread.interrupted());
				//System.out.println(Thread.currentThread().isInterrupted());
			}
			catch(Exception e) {
				
				//System.out.println(Thread.interrupted());
				//System.out.println(Thread.currentThread().isInterrupted());
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		ThreadInterrupted2 tid2=new ThreadInterrupted2();
		//System.out.println(Thread.interrupted());
		//System.out.println(Thread.currentThread().isInterrupted());
		tid2.start();
		tid2.interrupt();
		//System.out.println(Thread.interrupted());
		//System.out.println(Thread.currentThread().isInterrupted());
	}
}
