//single task using multiple thread
public class Thread2 extends Thread{
	public void run() {
		System.out.println("Thread Started");
	}
	public static void main(String[] args) {
		Thread2 t=new Thread2();
		t.start();
		Thread2 t1=new Thread2();
		t1.start();
	}	
}
