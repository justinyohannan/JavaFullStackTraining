//implements Runnable Interface
public class ThreadDemo2 implements Runnable {
	public void run() {
		System.out.println("Thread Started");
	}
	
	public static void main(String[] args) {
		//ThreadDemo2 t1=new ThreadDemo2();
		//Thread t=new Thread(t1);
		Thread t=new Thread(new ThreadDemo2());
		t.start();
	}
}
//start() is used to call the run(), when start is called a new stack is given to the thread and run() is invoked a new thread