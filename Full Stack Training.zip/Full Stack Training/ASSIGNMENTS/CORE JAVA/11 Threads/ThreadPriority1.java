
public class ThreadPriority1 {

}
