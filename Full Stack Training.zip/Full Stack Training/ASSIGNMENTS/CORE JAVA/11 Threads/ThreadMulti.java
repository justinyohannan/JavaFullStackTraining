//multiple task using multiple thread
class MyThread1 extends Thread {
	public void run() {
		System.out.println("MyThread1");
	}
}
class MyThread2 extends Thread {
	public void run() {
		System.out.println("MyThread2");
	}
}
class MyThread3 extends Thread {
	public void run() {
		System.out.println("MyThread3");
	}
}

public class ThreadMulti {
	public static void main(String[] args) {
		MyThread1 mt1=new MyThread1();
		mt1.start();
		
		MyThread2 mt2=new MyThread2();
		mt2.start();
		
		MyThread3 mt3=new MyThread3();
		mt3.start();
	}
}
