//Performing single task from single thread
public class Thread1 extends  Thread{
	public void run() {
		System.out.println("Thread Started");
	}
	public static void main(String[] args) {
		Thread1 t=new Thread1();
		t.start();
	}
}
