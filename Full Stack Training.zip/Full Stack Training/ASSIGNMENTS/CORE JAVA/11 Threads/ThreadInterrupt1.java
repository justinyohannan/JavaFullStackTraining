
public class ThreadInterrupt1 extends Thread{
	public void run() {
		try
		{
			for(int i=1;i<=3;i++) {
				System.out.println(i);
				Thread.sleep(2000);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		ThreadInterrupt1 ti=new ThreadInterrupt1();
		ti.start();
		ti.interrupt();
	}
}
