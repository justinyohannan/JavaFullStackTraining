
class BookTicket
{
	static int totalseats=12;
	static synchronized void bookSeat(int seats)
	{
		if(totalseats>=seats) {
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats: "+totalseats);
		}
		else {
			System.out.println("Seats are not available: "+totalseats);
		}
	}
}
class Thread3 extends Thread{
	static BookTicket b;
	int seats;
	Thread3(BookTicket b,int seats)
	{
		this.b=b;
		this.seats=seats;
	}
	public void run() {
		b.bookSeat(seats);
	}
}
class Thread4 extends Thread{
	static BookTicket b;
	int seats;
	Thread4(BookTicket b,int seats)
	{
		this.b=b;
		this.seats=seats;
	}
	public void run() {
		b.bookSeat(seats);
	}
}


public class ThreadSynch1 extends Thread {
	public static void main(String[] args) {
		BookTicket b=new BookTicket(); //12
		Thread3 t1=new Thread3(b, 8);  //12-8=4
		t1.start();
		Thread4 t2=new Thread4(b, 3);  //4-3=1
		t2.start();
		
		BookTicket b1=new BookTicket(); //12
		Thread3 t3=new Thread3(b, 3);   //12-3=9
		t3.start();
		Thread4 t4=new Thread4(b, 4);   //9-4=5
		t4.start();
		
	}
}
