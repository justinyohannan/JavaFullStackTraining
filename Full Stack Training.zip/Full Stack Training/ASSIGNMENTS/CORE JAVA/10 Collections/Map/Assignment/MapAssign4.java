//Map:Assignment 4

import java.util.HashMap;
import java.util.ArrayList;

class MapAssign4
{
	public static void main(String[] args)
	{
		CountryCapital  cc = new CountryCapital();
		
		cc.saveCountryCapital("India", "Delhi");
		cc.saveCountryCapital("Japan", "Tokyo");
		cc.saveCountryCapital("USA", "Washington DC");
		
		System.out.println(cc.getCountry("Berlin"));
		System.out.println(cc.getCapital("India"));
		
		// Countries as list
		ArrayList<String> alc = cc.countriesAsList();
		System.out.println(alc);
		
		// Reversed hashmap
		HashMap<String, String> m2 = cc.reverse();
		
		for(String k : m2.keySet()){
			System.out.print("Key: " + k + ", Value : " + m2.get(k) + " ");
		}
		
	}
}

class CountryCapital{
	private HashMap<String, String> m1;
	
	public CountryCapital(){
		this.m1 = new HashMap<>();
	}

	public void saveCountryCapital(String country, String capital){
		this.m1.put(country, capital);
	}
	
	public String getCapital(String country){
		return this.m1.get(country);
	}
	
	public String getCountry(String capital){
		for(String k : this.m1.keySet()){
			if(this.m1.get(k).equals(capital)){
				return k;
			}
		}
		return null;
	}
	
	public HashMap<String, String> reverse(){
		HashMap<String, String> m2 = new HashMap<>();
		
		for(String key : this.m1.keySet()){
			String value = this.m1.get(key);
			
			m2.put(value, key);
		}
		
		return m2;
	}
	
	public ArrayList<String> countriesAsList(){
		ArrayList<String> al = new ArrayList<>();
		for(String s : this.m1.keySet()){
			al.add(s);
		}
		
		return al;
	}
	
}