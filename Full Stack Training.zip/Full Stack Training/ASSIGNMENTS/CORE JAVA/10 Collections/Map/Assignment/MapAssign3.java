//Set: Assignment3
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
class MapAssign3
{
	public static void main(String gg[])
	{
		
		Map<Integer,String> map=new HashMap<>();
		
		map.put(001,"abc");
		map.put(002,"xyz");
		map.put(003,"jkl");
		
		int found=0;
		int sKey=Integer.parseInt(gg[0]);
		String sValue=gg[1];
		
		for(Map.Entry m:map.entrySet())
		{
			if(sValue.equals((String)m.getValue())) 
			{
				System.out.println("Found");
				found=1;
				break;
			}
		}
		if(found==0)
		{	
			System.out.println("Not found");
			found=0;
			for(Map.Entry m:map.entrySet())
			{
				if(sKey==(int)m.getKey()) 
				{
					System.out.println("Found");
					found=1;
					break;
				}
			}
		}
		
		if(found==0)
		{
			System.out.println("Not found");
		}
		System.out.println("Iterate map");
		for(Map.Entry m:map.entrySet())
		{
			System.out.println("Key :"+m.getKey()+" value :"+m.getValue());
		}
	}
}
