//Set:Assign2
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
class MapAssign2
{
	public static void main(String gg[])
	{
		Properties p=new Properties();
		p.setProperty("Madhya Pradesh","Bhopal");
		p.setProperty("Kerala","Thiruvanthapuram");
		p.setProperty("Bihar","Patna");
		
		Set set=p.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry m=(Map.Entry)i.next();
			System.out.println("State :"+m.getKey()+" Capital :"+m.getValue());
		}
	}	
}