//map: Assignment 1
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.*;
class MapAssign1
{
	public static void main(String[] args)
	{
		Map<String,String> hm=new HashMap<String,String>();
		hm.put("A","Apple");
		hm.put("B","Bannana");
		hm.put("C","Cat");
		hm.put("D","Deer");
		
		Set<String,String> s=hm.entrySet();
		
		Iterator<String,String> i=s.iterator();
		
		while(i.hasNext())
		{
			Map.Entry<String,String> hme=i.next();
			if(hme.getKey().equals("B"))
			{
				System.out.println("Key exists");
				break;
			}
		}
		
		while(i.hasNext())
		{
			Map.Entry<String,String> hme=i.next();
			if(hme.getValue().equals("Bannana"))
			{
				System.out.println("Value exists");
				break;
			}
		}
		
		while(i.hasNext())
		{
			Map.Entry<String,String> hme=i.next();
			System.out.println(hme);
		}
		
	}
}