//Map Example and its
import java.util.Map;
import java.util.*;
class Map1
{
	public static void main(String[] args)
	{
		//WITHOUT GENERICS
		
	/*	Map map=new HashMap();
		map.put(10,"yash");
		map.put(11,"technology");
		map.put(20,"Justin");
		Set s=map.entrySet();//converrt to set to traverse
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next(); //Value Separation
			System.out.println("Key:"+entry.getKey()+" Value:"+entry.getValue());
		
			//Map.Entry(Sub Interface) Interface we will get key and value separately
		
		}*/
		
		
		//USING GENERICS
		
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(10,"yash");
		map.put(11,"technology");
		map.put(20,"Justin");   		//keySet() containing all keys() 
		for(Map.Entry m:map.entrySet())//it returns the set containing all keys and values
		{
			System.out.println("Key:"+m.getKey()+" Value:"+m.getValue());
		}
	}

}