//Link List
import java.util.LinkedList;
import java.util.Iterator;
class LinkedList1
{
	public static void main(String[] args)
	{
		LinkedList<String> ll=new LinkedList<String>();
		ll.add("Justin");
		ll.add("Yohannan");
		ll.add("Yash");
		ll.add("Technologies");
		
		System.out.println(ll);
		
		ll.add(0,"Welcome");//to add element at specific index
		System.out.println(ll);
	
		for(String j: ll)
		{
			System.out.println(ll);
		}
		
	
		Iterator i=ll.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
			
		}
	
	
	}
	
}