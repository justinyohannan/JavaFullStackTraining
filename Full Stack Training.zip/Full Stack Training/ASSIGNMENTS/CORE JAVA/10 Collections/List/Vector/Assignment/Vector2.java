//list: Assignment 4
import java.util.Vector;
import java.util.Iterator;
import java.util.List;




class Vector2
{
	public static void main(String[] args)
	{

		List<Employee> l=new Vector<Employee>();
		Vector<Employee> vec=new Vector<Employee>();
		
		vec.add("Justin Yohannan");
		vec.add("Dev");
		vec.add("Indore");
		vec.add(1014808);
	
		System.out.println(vec);
		
		/*vec.add("Welcome");
		System.out.println("after adding: "+vec);
		
		for(String j: vec)
		{
			System.out.println(vec);
		}
		
		
		Iterator i=vec.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
			
		}*/
	
		
		
	}
	
} 