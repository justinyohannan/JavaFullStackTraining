import java.util.ArrayList;
import java.util.Vector;
import java.util.Iterator;

class VectorAssign1{
	public static void main(String[] args){
		
		ArrayList<String> al = new ArrayList<>();
		
		al.add("Jan");
		al.add("Feb");
		al.add("Mar");
		al.add("Apr");
		al.add("May");
		al.add("Jun");
		al.add("Jul");
		al.add("Aug");
		al.add("Sep");
		al.add("Oct");
		al.add("Nov");
		al.add("Dec");
		
		// Creating vector and adding all months from arraylist
		Vector<String> vec = new Vector<>();
		vec.addAll(al);
		
		// Iterating and printing the months
		Iterator itr = vec.iterator();
		while(itr.hasNext()){
			System.out.print(itr.next() + " ");
		}
		
		
	}
}