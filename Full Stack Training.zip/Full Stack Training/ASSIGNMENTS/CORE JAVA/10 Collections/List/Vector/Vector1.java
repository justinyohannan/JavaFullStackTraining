//Vector
import java.util.Vector;
import java.util.Iterator;

class Vector1
{
	public static void main(String[] args)
	{
		Vector<String> vec=new Vector<String>();
		
		vec.add("Justin");
		vec.add("Yohannan");
		vec.add("Yash");
		vec.add("technologies");
	
		System.out.println(vec);
		
		vec.add("Welcome");
		System.out.println("after adding: "+vec);
		
		for(String j: vec)
		{
			System.out.println(vec);
		}
		
		
		Iterator i=vec.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
			
		}
	
		
		
	}
	
} 