//array list for months of year
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
class ArrList2
{
	public static void main(String[] args)
	{
		ArrayList<String> als=new ArrayList<String>();
		als.add("JANUARY");
		als.add("FEBRUARY");
		als.add("MARCH");
		als.add("APRIL");
		als.add("MAY");
		als.add("JUNE");
		als.add("JULY");
		als.add("AUGUST");
		als.add("SEPTEMBER");
		als.add("OCTOBER");
		als.add("NOVEMBER");
		als.add("DECEMBER");
		System.out.println("Normal Method: "+als);

//List Iterator and its method		
		ListIterator li=als.listIterator();
		li.next();
		li.next();
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
			
		}
		
		li.set("MONTHS");
		System.out.println(als);
		li.remove();//removes element at index 0 
		System.out.println(als);

//Iterator and its methods		
		/*Iterator i=als.iterator();//here iterator is an interface so we cant make object so we use object_of_arraylist.iterator() 
		while(i.hasNext())
		{
			System.out.println("Iterator Method "+i.next());
		}
		
		for(String j:als)
		{
			System.out.println("For Each: "+j);
		}*/
	}
}