import java.util.ArrayList;
import java.util.Iterator;
class ArrList1
{
	public static void main(String[] args)
	{
		ArrayList<String> als=new ArrayList<String>();
		al.add("JANUARY");
		al.add("FEBRUARY");
		al.add("MARCH");
		al.add("APRIL");
		al.add("MAY");
		al.add("JUNE");
		al.add("JULY");
		al.add("AUGUST");
		al.add("SEPTEMBER");
		al.add("OCTOBER");
		al.add("NOVEMBER");
		al.add("DECEMBER");
		System.out.println(als);
		
		Iterator i=als.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		for(String j:als)
		{
			System.out.println("For Each: "+j)
		}
	}
}