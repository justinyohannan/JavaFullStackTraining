import java.util.TreeSet;
import java.util.Iterator;

class TreeSetAssign1
{
	public static void main(String[] args)
	{
		TreeSet<String> ts = new TreeSet<>();
		
		ts.add("Yash");
		ts.add("Justin");
		ts.add("23");
		ts.add("1233");
		ts.add("Ramesh");
		
		
		// Now we will iterate the elements of the TreeSet 
		Iterator itr = ts.iterator();
		while(itr.hasNext())
		{
			System.out.print(itr.next()+" ");
		}
		
		System.out.println("");
		
		
		// Now we will iterate in reverse order
		Iterator itr2 = ts.descendingIterator();
		while(itr2.hasNext())
		{
			System.out.print(itr2.next()+" ");
		}
		
		System.out.println("");
		
		// Check if a particular element exist or not
		System.out.println(ts.contains("Justin"));
		System.out.println(ts.contains("23"));
		System.out.println(ts.contains("Yash"));
	}
}