import java.util.HashSet;
import java.util.Iterator;

class HashSetAssign1
{
	public static void main(String[] args)
	{
		
			Countries c = new Countries();
			
			c.saveCountryName("India");
			c.saveCountryName("Spain");
			c.saveCountryName("England");
			
			System.out.println(c.getCountry("India"));
			System.out.println(c.getCountry("England"));
			
			System.out.println(c.getCountry("America")); // returns null
			
	}
}


class Countries
{
	private HashSet<String> H1;
	
	Countries()
	{
		this.H1 = new HashSet<>();
	}
	
	
	
	public void saveCountryName(String name)
	{
		this.H1.add(name);
	}
	
	
	public String getCountry(String name)
	{
		Iterator itr = this.H1.iterator();
		while(itr.hasNext())
		{
			String c = (String)itr.next();
			if(c.equals(name))
			{
				return c;
			}
		}
		
		return null;
	}
}