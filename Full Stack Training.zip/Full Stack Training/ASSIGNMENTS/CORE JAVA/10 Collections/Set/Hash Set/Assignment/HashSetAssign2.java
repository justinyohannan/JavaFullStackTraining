import java.util.HashSet;
import java.util.Iterator;

class HashSetAssign2
{
	public static void main(String[] args)
	{
		HashSet<String> hs=new HashSet<>();
		hs.add("Amit");
		hs.add("Bhanu");
		hs.add("Justin");

		Iterator<String> itr=hs.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}	
	}
}