//Hash Set
import java.util.HashSet;
import java.util.Iterator;
class HashSet1
{
	public static void main(String[] args)
	{
		HashSet<String> hs=new HashSet<String>();
		hs.add("A");
		hs.add("B");
		hs.add("C");
		hs.add("D");
		hs.add("E");
	
		System.out.println(hs);
		
		for(String j: hs)
		{
			System.out.println(hs);
		}
		
		hs.add("F");
		System.out.println(hs);
		
		Iterator i=hs.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
			
		}
	}
}