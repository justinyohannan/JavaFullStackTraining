//queue example and its various methods
import java.util.Queue;
import java.util.PriorityQueue;
import java.util.Iterator;
import java.util.LinkedList;
class Queue1
{
	public static void main(String[] args)
	{
		Queue<Integer> pq=new PriorityQueue<Integer>();
		pq.add(100);
		pq.add(200);
		pq.add(300);
		System.out.println(pq.peek());//head of the queue=100
		System.out.println(pq.poll());//100-->first retrieves the top of queue and then removes it from queue
		System.out.println(pq.peek());//200-->head of the queue
		pq.remove();//it will remove head of the queue i.e. 200
		System.out.println(pq);//only 300 is printed 
		
		
		//
		
		Queue<Integer> ql=new LinkedList<Integer>();
		ql.add(1000);
		ql.add(2000);
		ql.add(3000);
		System.out.println(ql.peek());//1000
		System.out.println(ql.poll());//1000
		System.out.println(ql.peek());//2000
		//ql.poll();-->2000
		//ql.poll();-->3000
		//here queue gets empty so it will throw exception but not in poll
		
	}
}