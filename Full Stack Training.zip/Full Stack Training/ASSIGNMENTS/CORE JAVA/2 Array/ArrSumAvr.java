//Topic-2: Assignment 1: sum and average of 1D array
class ArrSumAvr
{
	public static void main(String[] args)
	{
		int[] a= {10,20,30};
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		System.out.println(sum);
		float average=(sum)/a.length;
		System.out.println(average);
	}
}