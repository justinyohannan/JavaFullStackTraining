//Topic-2: Assignment 1: sum and average of 2D array
class ArrSumAvr2
{
	public static void main(String[] args)
	{
		int[][] a= {{10,20,30},{40,50,60}};
		int sum=0;
		int aLength= a.length*a[0].length;
		for(int row=0;row<a.length;row++)
		{
			for(int col=0;col<a[row].length;col++)
			{
				sum=sum+a[row][col];
			}
		}
		System.out.println(sum);
		float average=(sum)/aLength;
		System.out.println(average);
	}
}