class Assign2
{
	public static void main(String[] args)
	{
		int[] a = {23,65,21,11,77,54};
		minMax(a);
	}
	
	static void minMax(int[] a)
	{
		int min = a[0];
		int max = a[0];
		
		for(int i = 0; i < a.length; i++)
		{
			if(a[i] > max)
			{
				max = a[i];
			}
			
			if(a[i] < min)
			{
				min = a[i];
			}
		}
		System.out.println("Minimum value : " + min);
		System.out.println("Maximum value : " + max);
	}
}