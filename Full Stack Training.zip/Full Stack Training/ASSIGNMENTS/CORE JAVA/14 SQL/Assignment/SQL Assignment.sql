show databases;
use justin;
CREATE TABLE EmployeeInfo(
EmpID INTEGER PRIMARY KEY,
EmpFname VARCHAR(20) NOT NULL,
EmpLname VARCHAR(20) NOT NULL,
Department VARCHAR(10) NOT NULL,
Project VARCHAR(10) NOT NULL,
Address VARCHAR(20) NOT NULL,
DOB date NOT NULL,
Gender VARCHAR(1) NOT NULL
);

CREATE TABLE EmployeePosition(
EmpID INTEGER NOT NULL,
EmpPosition VARCHAR(20) NOT NULL,
DateOfJoining DATE NOT NULL,
SALARY INTEGER NOT NULL
);



INSERT INTO EmployeeInfo VALUES (1, 'Sanjay','Mehra','HR','P1','Hyderabad(HYD)','1976-12-01','M');
INSERT INTO EmployeeInfo VALUES (2, 'Ananya','Mishra','Admin','P2','Delhi(DEL)','1968-05-02','F');
INSERT INTO EmployeeInfo VALUES (3, 'Rohan','Diwan','Account','P3','Mumbai(BOM)','1980-01-01','M');
INSERT INTO EmployeeInfo VALUES (4, 'Sonia','Kulkarni','HR','P1','Hyderabad(HYD)','1992-05-02','F');
INSERT INTO EmployeeInfo VALUES (5, 'Ankit','Kapoor','Admin','P2','Delhi(DEL)','1994-07-03','M');

SELECT * FROM EmployeeInfo;

INSERT INTO EmployeePosition VALUES(1, 'Manager', '2022-05-01',500000);
INSERT INTO EmployeePosition VALUES(2, 'Executive', '2022-05-02',75000);
INSERT INTO EmployeePosition VALUES(3, 'Manager', '2022-05-01',90000);
INSERT INTO EmployeePosition VALUES(2, 'Lead', '2022-05-02',85000);
INSERT INTO EmployeePosition VALUES(1, 'Executive', '2022-05-01',300000);

SELECT * FROM EmployeePosition;

-- SELECT upper(EmpFname) AS EmpName FROM EmployeeInfo;

-- SELECT count(*) FROM employeeinfo WHERE Department='HR';

-- SELECT curdate();

-- SELECT substr(EmpLname,1,4) from employeeinfo;

-- SELECT MID(Address, 1, locate('(', Address)-1) FROM EmployeeInfo;

-- CREATE TABLE DemoEmployeeInfo SELECT * FROM EmployeeInfo;
-- SELECT * FROM DemoEmployeeInfo;
-- select * FROM EmployeeInfo as ei , EmployeePosition as ep WHERE ei.EmpId = ep.EmpId AND ep.SALARY between 50000 AND 100000;

-- SELECT EmpFname FROM EmployeeInfo WHERE EmpFname LIKE 'S%';

-- SELECT * FROM employeeinfo LIMIT 3;

-- SELECT concat(EmpFname," ",EmpLname) AS FullName FROM employeeinfo;

-- SELECT Gender ,count(*) FROM employeeinfo where DOB between '1960-05-02' AND '1975-12-31' ORDER BY Gender;

-- SELECT * FROM employeeinfo ORDER BY EmpLname desc, Department asc;

-- SELECT * FROM employeeinfo WHERE EmpLname like '____A';

-- SELECT * FROM employeeinfo where EmpFname NOT IN ("Sanjay","Sonia");

-- SELECT * FROM employeeinfo where Address="DELHI(DEL)"

-- select * FROM employeeposition where EmpPosition="MANAGER"; 

-- SELECT Department, COUNT(*) FROM EmployeeInfo group by Department ORDER BY Department;

-- SELECT * FROM employeeinfo where EmpID % 2 = 0;
-- SELECT * FROM employeeinfo where EmpID % 2 != 0;

-- select * FROM employeeinfo natural join employeeposition;

-- Minimum 2
-- SELECT SALARY FROM EmployeePosition ORDER BY Salary LIMIT 2;
-- Maximum 2
-- SELECT SALARY FROM EmployeePosition ORDER BY Salary DESC LIMIT 2;

-- SELECT  Salary FROM EmployeePosition as ep1 WHERE 0 = (SELECT COUNT(Salary) FROM EmployeePosition as ep2 WHERE ep2.Salary > ep1.Salary);

-- SELECT * FROM EmployeeInfo GROUP by EmpID HAVING COUNT(EmpId) > 1;

-- SELECT * FROM EmployeeInfo ORDER BY Department;

-- SELECT * FROM EmployeeInfo ORDER BY EmpID DESC LIMIT 3;

-- SELECT SALARY FROM EmployeePosition as ep1 WHERE 2 = (SELECT COUNT(*) FROM EmployeePosition as ep2 WHERE ep2.Salary > ep1.Salary);
