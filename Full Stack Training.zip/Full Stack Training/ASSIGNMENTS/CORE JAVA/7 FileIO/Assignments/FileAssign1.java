import java.io.FileReader;
class FileAssign1{
	public static void main(String[] args) throws Exception{
	
		int lines = 0;
		int words = 0;
		int characters = 0;
		int spaces = 0;
		
		FileReader in = new FileReader("D:/yash.txt");
		int i;
		
		while((i = in.read()) != -1){
			char c = (char)i;
			characters++;
			if(c == ' '){
				spaces++;
				words++;
			}
			if(c == '.'){
				lines++;
			}
		}
		
		System.out.println("No of lines: " + lines);
		System.out.println("No of words: " + words);
		System.out.println("No of characters: " + characters);
		System.out.println("No of spaces: " + spaces);
	}
}