import java.util.Scanner;
import java.io.FileReader;


class FileAssign3{
	public static void main(String[] args) throws Exception {
			
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Enter the file name: ");
			String file = scanner.next();
			System.out.println("Enter the character who's occurens is to countered: ");
			String userInput = scanner.next();
			
			char user = userInput.charAt(0);
			int userCharacterCounter = 0;
			
			
			
			FileReader fr = new FileReader("d:/"+file);
			int z;
			
			while((z = fr.read()) != -1){
				if ((char)z == user){
					userCharacterCounter++;
				}
			}
			
			System.out.println("file "+file+" has "+userCharacterCounter+" instances of letter "+userInput);
			
	}
}