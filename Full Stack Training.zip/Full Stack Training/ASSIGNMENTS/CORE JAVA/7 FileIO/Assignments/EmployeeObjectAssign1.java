//objectStream Assignment 1:getter setter
import java.io.*;
import java.util.Scanner;
class Employee implements Serializable
{
	private String name;
	private String department;
	private String designation;
	private double salary;
	
	public void setName(String name)
	{
		this.name=name;
	}
	public void setDepartment(String department)
	{
		this.department=department;
	}
	public void setDesignation(String department)
	{
		this.designation=designation;
	}
	public void setSalary(double salary)
	{
		this.salary=salary;
	}
	public String getName()
	{
		return name;
	}
	public String getDepartment()
	{
		return department;
	}
	public String getDesignation()
	{
		return designation;
	}
	public double getSalary()
	{
		return salary;
	}
	
	public String toString()
	{
		return name+" "+department+" "+designation+" "+salary;
	}
}
class EmployeeObjectAssign1
{
	public static void main(String[] args) throws Exception
	{
		Employee e=new Employee();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name:");
		e.setName(sc.nextLine());
		System.out.println("Enter the department:");
		e.setDepartment(sc.nextLine());
		System.out.println("Enter the designation:");
		e.setDesignation(sc.nextLine());
		System.out.println("Enter the salary:");
		e.setSalary(sc.nextDouble());
		
		File f=new File("D:/Records/Yash.txt");
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
		
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
		e= (Employee)ois.readObject();
		System.out.println(e);
		ois.close();
	}	
}