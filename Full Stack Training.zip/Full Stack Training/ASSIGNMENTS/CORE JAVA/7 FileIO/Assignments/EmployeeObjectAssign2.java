//objectStream Assignment 2:getter setter & constructors
import java.io.*;
import java.util.Scanner;
class Employee implements Serializable
{
	private String name;
	private String department;
	private String designation;
	private double salary;
		
	Employee(String name, String department, String designation, double salary)
	{
		this.name=name;
		this.department=department;
		this.designation=designation;
		this.salary=salary;
	}

	public void setName(String name)
	{
		this.name=name;
	}
	public void setDepartment(String department)
	{
		this.department=department;
	}
	public void setDesignation(String department)
	{
		this.designation=designation;
	}
	public void setSalary(double salary)
	{
		this.salary=salary;
	}
	public String getName()
	{
		return name;
	}
	public String getDepartment()
	{
		return department;
	}
	public String getDesignation()
	{
		return designation;
	}
	public double getSalary()
	{
		return salary;
	}	
	
	public String toString()
	{
		return name+" "+department+" "+designation+" "+salary;
	}
}
class EmployeeObjectAssign2
{
	public static void main(String[] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the name:");
		String name=sc.nextLine();
		
		System.out.println("Enter the department:");
		String department=sc.nextLine();
		
		System.out.println("Enter the designation:");
		String designation=sc.nextLine();
		
		System.out.println("Enter the salary:");
		double salary=sc.nextDouble();
		
		Employee e= new Employee(name,department,designation,salary);
		File f=new File("D:/Records/Yash.txt");
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
		
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
		e= (Employee)ois.readObject();
		System.out.println(e);
		ois.close();
	}
}