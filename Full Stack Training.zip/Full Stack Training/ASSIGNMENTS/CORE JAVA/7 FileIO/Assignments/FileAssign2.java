import java.io.FileReader;

class FileAssign2{
	public static void main(String[] args) throws Exception{
		
		int a = 0;
		int e = 0;
		int i = 0;
		int o = 0;
		int u = 0;
		
		FileReader fr = new FileReader("d:/yash.txt");
		int x;
		while((x = fr.read()) != -1){
			char c = (char)x;
			if(c == 'a' || c == 'A'){
				a++;
			}
			if(c == 'e' || c == 'E'){
				e++;
			}
			if(c == 'i' || c == 'I'){
				i++;
			}
			if(c == 'o' || c == 'O'){
				o++;
			}
			if(c == 'u' || c == 'U'){
				u++;
			}
		}
		
		System.out.println("Number of a: " +  a);
		System.out.println("Number of e: " +  e);
		System.out.println("Number of i: " +  i);
		System.out.println("Number of o: " +  o);
		System.out.println("Number of u: " +  u);
	}
}