//assignment 4
class MathOperation
{
	public static void main(String[] args)
	{
		try
		{
			int a=Integer.parseInt(args[0]);
			int b=Integer.parseInt(args[1]); 
			int c=Integer.parseInt(args[2]);
			int d=Integer.parseInt(args[3]);
			int e=Integer.parseInt(args[4]);
			int[] arr={a,b,c,d,e};
			int sum=0;
			
			for(int i=0;i<arr.length;i++)
			{
				sum=sum+arr[i];
			}
			System.out.println("Sum is"+sum);
			
			double avr=(sum)/arr.length;
			System.out.println("average is"+avr);
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
	}
}