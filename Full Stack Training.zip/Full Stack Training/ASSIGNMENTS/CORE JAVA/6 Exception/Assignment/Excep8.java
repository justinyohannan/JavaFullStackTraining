//Assignment 8
class AriExcep extends RuntimeException
{
	AriExcep()
	{
		super();
	}
}
class Excep8 
{
	public static void main(String[] args)
	{
		try
		{
			int a=Integer.parseInt(args[0]);
			int b=Integer.parseInt(args[1]);
			int c=a/b;
			System.out.println("the quotient is"+c);
		}
		catch(AriExcep e)
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("Inside Finally block");
		}
	}
}