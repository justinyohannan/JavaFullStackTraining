//topic 6: Assignment 1
class Excep1
{
	public static void main(String[] args)
	{
		
		try
		{
			int a=Integer.parseInt(args[0]);
			System.out.println("Enter the input"+args[0]);
			System.out.println(a*a);
		}
		catch(NumberFormatException e)
		{
			System.out.println(e);
			System.out.println("entered input is not valid format for an integer");
		}
		
			
	}
}