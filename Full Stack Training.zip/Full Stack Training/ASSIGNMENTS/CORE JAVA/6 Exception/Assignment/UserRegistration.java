//assignment 7
class InvalidCountryException extends RuntimeException
{
	InvalidCountryException()
	{
		super();
		System.out.println("InvalidCountryException occurred");
		System.out.println("user outside india cannot be registered");
	}
}
class UserRegistration
{
	void registerUser(String Username,String userCountry)
	{
		if(!userCountry.equals("India"))
		{
			throw new InvalidCountryException();
		}
		else
		{
			System.out.println("User registeration done successfully");
		}
	}
	public static void main(String[] args)
	{
		UserRegistration ur=new UserRegistration();
		try
		{
			//ur.registerUser("Alexa","France");
			ur.registerUser("Justin","India");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
}