//throws keyword
import java.io.FileInputStream;
import java.io.FileNotFoundException;
class ThrowsD
{
	void show() throws FileNotFoundException
	{
		FileInputStream f=new FileInputStream("D:/yash.txt");
	}
}
class ThrowsDemo
{
	public static void main(String[] args)
	{
		ThrowsD t=new ThrowsD();
		try
		{
			t.show();
		}
		catch()
		{
			e.printStackTrace();
		}

		System.out.println("Normal Termination");
	}
}