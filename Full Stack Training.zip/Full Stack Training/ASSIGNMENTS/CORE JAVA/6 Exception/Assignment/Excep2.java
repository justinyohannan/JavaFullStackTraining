//assignment 2
class Excep2
{
	public static void main(String[] args)
	{
		try
		{
			int[] a={10,20};
			System.out.println(a[3]);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}