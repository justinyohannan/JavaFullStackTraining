class A{
 int[] arr=new int[4];
}
interface B{}
class Test3
{
	public static void main(String[] args)
	{
		try
		{
			Class c=Class.forName("A");
			System.out.println(c.isArray());
			
			Class c1=Class.forName("B");
			System.out.println(c1.isArray());
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}