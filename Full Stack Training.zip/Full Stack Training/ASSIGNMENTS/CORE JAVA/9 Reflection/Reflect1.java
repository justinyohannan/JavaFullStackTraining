//reflection API program
import java.lang.reflect.Method;

class Test
{
	
}
class Reflect1
{
	public static void main(String[] args) throws Exception
	{
		Class c=Class.forName("Test");
		System.out.println(c.getName());
	}
}