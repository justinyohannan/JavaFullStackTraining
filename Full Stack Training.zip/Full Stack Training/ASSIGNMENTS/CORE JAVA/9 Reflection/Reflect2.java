//reflection program : getClass() method of object class
class Test1
{

}
class Reflect2
{
	public void show(Object obj)
	{
		Class c=obj.getClass();
		System.out.println(c.getName());
	}
	public static void main(String[] args)
	{
		Test1 t=new Test1();
		Reflect2 ref=new Reflect2();
		ref.show(t);
	}
}