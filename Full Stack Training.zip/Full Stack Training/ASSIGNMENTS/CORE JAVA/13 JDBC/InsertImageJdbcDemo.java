//to store image in database
import java.sql.*;
import java.io.*;
class InsertImageJdbcDemo
{
	public static void main(String[] args)
	{
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			
			
			String url="jdbc:mysql://localhost:3307/newfile";
			String user="root";
			String pass="root123";
			Connection con=DriverManager.getConnection(url,user,pass);
			
			String q="insert into myimage value(?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			
			
			FileInputStream f=new FileInputStream("d:\\ocean.jpg");
			ps.setBinaryStream(2,f,f.available());
			ps.setString(1,"ocean");
			int i=ps.executeUpdate();
			System.out.println("Inserted successfully");
			
			con.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}
}