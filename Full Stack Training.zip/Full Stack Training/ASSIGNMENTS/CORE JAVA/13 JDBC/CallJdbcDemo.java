//Callable Statement: insertion
import java.sql.*;
class CallJdbcDemo
{
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			String url="jdbc:mysql://localhost:3307/yash";
			String user="root";
			String pass="root123";
			Connection con=DriverManager.getConnection(url,user,pass);
			
			CallableStatement cs=con.prepareCall("{call insertR(?,?)}");
			cs.setInt(1,120303);
			cs.setString(2,"Sumit");
			cs.executeUpdate();
			System.out.println("inserting successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}
}