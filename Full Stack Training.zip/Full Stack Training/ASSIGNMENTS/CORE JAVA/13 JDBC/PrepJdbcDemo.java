//Prepared Statement: inserting query
import java.sql.*;
class PrepJdbcDemo
{
	public static void main(String[] args)
	{
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//creating connection
			String url="jdbc:mysql://localhost:3307/yash";
			String user="root";
			String pass="root123";
			Connection con=DriverManager.getConnection(url,user,pass);
			
			//creating query
			String q="insert into employee(empID,name) value(?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			
			//setting the values
			ps.setInt(1,2400);
			ps.setString(2,"Yash");
			ps.executeUpdate();
			System.out.println("Inserted successfully");
			
			
			con.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}
}


/* to insert the data using bufferedreader

try
{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//creating connection
			String url="jdbc:mysql://localhost:3307/yash";
			String user="root";
			String pass="root123";
			Connection con=DriverManager.getConnection(url,user,pass);
			
			//creating query
			String q="insert into employee(empID,name) value(?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter EmpID:");
			int id=Integer.parseInt(br.readLine());
			System.out.println("Enter name");
			String name=br.readLine();
			
			//setting the values
			ps.setInt(1,2400);
			ps.setString(2,"Yash");
			ps.executeUpdate();
			System.out.println("Inserted successfully");
			
			
			con.close();
}
*/

