class Assign3
{
	public static void main(String[] args)
	{
		int year = Integer.parseInt(args[0]);
		
		if(year % 4 == 0)
		{
			if(year % 100 == 0)
			{
				if(year % 400 == 0)
				{
					System.out.println("This is a Leap year");
				}
				else
				{
					System.out.println("This is not a Leap year");
				}
			}
			else
			{
				System.out.println("This is not a Leap year");
			}
		}
		else
		{
			System.out.println("This is not a Leap year");
		}	
		
	}
}