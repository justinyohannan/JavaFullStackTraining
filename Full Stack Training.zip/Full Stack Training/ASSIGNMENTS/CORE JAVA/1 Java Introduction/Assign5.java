class Assign5
{
	public static void main(String [] args)
	{
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		
		int temp = a;
		a = b;
		b = temp;
		
		System.out.println(a + " " + b);
	}
}