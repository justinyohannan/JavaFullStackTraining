class Assign4
{
	public static void main(String[] args)
	{
		
		int x = Integer.parseInt(args[0]);
		
		switch(x)
		{
			case 1:
				System.out.println(Integer.parseInt(args[1]) + Integer.parseInt(args[2]));
				break;
			
			case 2:
				System.out.println(Integer.parseInt(args[1]) - Integer.parseInt(args[2]));
				break;
				
			case 3:
				System.out.println(Integer.parseInt(args[1]) * Integer.parseInt(args[2]));
				break;
				
			case 4:
			
				System.out.println(Integer.parseInt(args[1]) / Integer.parseInt(args[2]));
				break;
		}
	}
}