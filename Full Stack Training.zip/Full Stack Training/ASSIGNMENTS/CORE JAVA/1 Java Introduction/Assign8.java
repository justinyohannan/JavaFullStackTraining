class Assign8
{
	public static void main(String[] args)
	{
		int a=Integer.parseInt(args[0]);
		int f=1;
		
		for(int i=1;i>=1;i++)
		{
			f=f*i;
		}
		
		System.out.println("Factorial of "+a+" is "+f);
	}
}