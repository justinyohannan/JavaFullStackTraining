public class EnumDemo {
	enum Directions{
		EAST(10), WEST(20), NORTH(30), SOUTH(30);
		int val;
		Directions(int val){
			this.val = val;
		}
	}
	
	public static void main(String[] args){
		Directions d = Directions.SOUTH;
		System.out.println(d);
		
		for(Directions e  : Directions.values()){
			System.out.println(e + ", value: " + e.val);
		}
	}
}

