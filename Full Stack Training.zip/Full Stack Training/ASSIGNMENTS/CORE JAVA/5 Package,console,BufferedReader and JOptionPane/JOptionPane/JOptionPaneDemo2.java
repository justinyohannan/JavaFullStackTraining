//JOptionPane Message Dialogue box
import javax.swing.*;  
public class JOptionPaneDemo2 
{  
	JFrame f;  
	JOptionPaneDemo2()
	{  
		f=new JFrame();  
		JOptionPane.showMessageDialog(f,"Welcome to Yash Technologies");  
	}  
	public static void main(String[] args) 
	{  
		new JOptionPaneDemo2();
		System.exit(0);	
	}  
}  