//JoptionPane programs
import javax.swing.*;  
class JOptionPaneDemo 
{  
	JFrame f;  
	JOptionPaneDemo()
	{  
		f=new JFrame();   
		String name=JOptionPane.showInputDialog(f,"Enter Your Name");      
	}  
	public static void main(String[] args) 
	{  
		new JOptionPaneDemo();
		System.exit(0);
	}  
}  