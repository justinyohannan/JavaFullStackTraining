//programs for console class
import java.io.Console;
class ConsoleDemo
{
	public static void main(String[] args)
	{
		String str;char ch[];
		Console ob = System.console();
		System.out.println(" Enter Username");
		str=ob.readLine();
		System.out.println(" Enter Password");
		ch=ob.readPassword();
		String a=String.valueOf(ch);
		System.out.println("Username :"+str+"Password:"+ch);
		System.out.println("Actual Password:"+a);
	}
}