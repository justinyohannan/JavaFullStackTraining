package pack;
public class Hello
{
	public void display()
	{
		System.out.println("Hello in Hello class ");
	}
}