//package assignment 1 continue
import Test.Foundation;
class TestDemo
{
	public static void main(String[] args)
	{
		Foundation f = new Foundation();
		//System.out.println("var1 accessible" +f.var1);
		//System.out.println("var2 accessible" +f.var2);
		//System.out.println("var3 accessible" +f.var3);
		System.out.println("var4 accessible" +f.var4);
	}
}


/* Output:only var4 is accessible*/