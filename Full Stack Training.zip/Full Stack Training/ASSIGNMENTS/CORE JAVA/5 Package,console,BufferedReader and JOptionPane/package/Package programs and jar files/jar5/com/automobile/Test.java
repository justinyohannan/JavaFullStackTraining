package com.automobile.twowheeler;

class Test
{
	public static void main(String[] args)
	{
		Hero he=new Hero("SFJFJLSDF","GDGDG56S64","JUSTIN YOHANNAN",100);
		he.getModelName();
		he.getRegistrationNumber();
		he.getOwnerName();
		he.getSpeed();
		he.radio();
		
		Honda hon=new Honda("SFSLJGLDLG","FFSWF6456","JUSTIN YOHANNAN",110);
		hon.getModelName();
		hon.getRegistrationNumber();
		hon.getOwnerName();
		hon.getSpeed();
		hon.cdplayer();
	}
}