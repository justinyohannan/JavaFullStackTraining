import pack.Hello
class PackageDemo2
{
	public static void main(String[] args)
	{
		Hello ob=new Hello();
		ob.display();
	
	}
}