// package assignment 2:
import com.automobile.Vehicle;
class Hero extends Vehicle
{
	private String modelName;
	private String registrationNumber;
	private String ownerName;
	private int speed;
	 
	Hero(String modelName, String registrationNumber, String ownerName, int speed)
	{
		this.modelName=modelName;
		this.registrationNumber=registrationNumber;
		this.ownerName=ownerName;
		this.speed=speed;
	}
	
	public String getModelName()
	{
		System.out.println("Model name:" +modelName);
	}
	public String getRegistrationNumber()
	{
		System.out.println("Registration name:" +registrationNumber);
	}
	public String getOwnerName()
	{
		System.out.println("Owner name" +ownerName);
	}
	public int getSpeed()
	{
		return speed;
	}
	public void radio()
	{
		System.out.println("Access radio");
	}
}
class Honda extends Vehicle
{
	private String modelName;
	private String registrationNumber;
	private String ownerName;
	private int speed;
	
	Honda(String modelName, String registrationNumber, String ownerName,int speed)
	{
		this.modelName=modelName;
		this.registrationNumber=registrationNumber;
		this.ownerName=ownerName;
		this.speed=speed;
	}
	
	public String getModelName()
	{
		System.out.println("model name:" +modelName);
	}
	public String getRegistrationNumber()
	{
		System.out.println("Registration Number" +registrationNumber);
	}
	public String getOwnerName()
	{
		System.out.println("Owner name" +ownerName);
	}
	public int getSpeed()
	{
		return speed;
	}
	public void cdplayer()
	{
		System.out.println("access cd player");
	}
}
class Test
{
	public static void main(String[] args)
	{
		Vehicle v=new Vehicle();
		Hero he=new Hero("SFJFJLSDF","GDGDG56S64","JUSTIN YOHANNAN",100);
		he.getModelName();
		he.getRegistrationNumber();
		he.getOwnerName();
		he.getSpeed();
		he.radio();
		
		Honda hon=new Honda("SFSLJGLDLG","FFSWF6456","JUSTIN YOHANNAN",110);
		hon.getModelName();
		hon.getRegistrationNumber();
		hon.getOwnerName();
		hon.getSpeed();
		hon.cdplayer();
	}
}